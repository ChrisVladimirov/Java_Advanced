import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int[] stones = Arrays.stream(reader.readLine().split("[, ]+")).mapToInt(Integer::parseInt).toArray();
        Lake lake = new Lake(stones);
        Iterator<Integer> froggy = lake.iterator();

        List<String> result = new ArrayList<>();
        while (froggy.hasNext()) {
            result.add(froggy.next() + "");
        }
        System.out.println(String.join(", ", result));
    }
}