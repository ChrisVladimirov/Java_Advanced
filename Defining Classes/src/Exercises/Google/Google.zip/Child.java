package Exercises.Google;

/*public class Child {
    private String name;
    private String childBirthday;

    public Child(String name, String childBirthday) {
        this.name = name;
        this.childBirthday = childBirthday;
    }
    @Override
    public String toString() {
        return name + " " + childBirthday;
    }
}*/public class Child {
    private String childName;
    private String childBirthday;

    public Child(String childName, String childBirthday) {
        this.childName = childName;
        this.childBirthday = childBirthday;
    }

    @Override
    public String toString() {
        return childName + " " + childBirthday;
    }

}
