package Exercises.Google;

/*public class Car {
   private String model;
    private int velocity;

    public Car(String model, int velocity) {
        this.model = model;
        this.velocity = velocity;
    }

    @Override
    public String toString(){
        return String.format("%s %d",this.model,this.velocity);
    }
}*/public class Car {
    private String carModel;
    private int carSpeed;

    public Car(String carModel, int carSpeed){
        this.carModel = carModel;
        this.carSpeed = carSpeed;
    }

    @Override
    public String toString() {
        return carModel + " " + carSpeed;
    }
}
