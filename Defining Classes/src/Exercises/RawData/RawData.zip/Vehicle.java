package Exercises.RawData;

import java.util.ArrayList;
import java.util.List;

public class Vehicle {
    private String model;
    private Engine engine;
    private Cargo cargo;
    private final List<Tyre> tyres;

    public Vehicle() {
        this.tyres = new ArrayList<>();
    }

    public void setCargo(Cargo cargo) {
        this.cargo = cargo;
    }

    public Cargo getCargo() {
        return cargo;
    }

    public List<Tyre> getTyres() {
        return tyres;
    }

    public Engine getEngine() {
        return engine;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setEngine(Engine engine) {
        this.engine = engine;
    }

    @Override
    public String toString() {
        return "Vehicle{" +
                "model='" + model + '\'' +
                ", engine=" + engine +
                ", cargo=" + cargo +
                ", tyres=" + tyres +
                '}';
    }
}
